function home () {

    // ` this is a "back tick". Use it to define multi-line strings in JavaScript.
    var content = `
    <h2>My Home Page Content</h2>
    <p> 
        Heres some home page text content along with an embeded link, 
        this link can go to another page on this website or a different link. 
        this world is your oyster. 
        <a href="https://www.pexels.com/search/animal/">Check out these cool animals here</a>

    </p>    
    
    <p> 
        here are some images with text blurbs, the images and text can be whatever is needed and
        can be placed on the page as needed.
    </p> 

   
    <p style="text-align:left;">
        heres some text about the picture under it. 
    </p> 
    <p style="text-align:left;">
        <img src="pics/TwinFuchs.jpg" style="width:25%; border-radius:10px;">
    </p>
    
    <p style="text-align:center;"> 
        heres some text about the picture under it. 
    </p>
    <p style="text-align:center;">
        <img src="pics/cuteRedCat.jpg" style="width:25%; border-radius:10px;">
    </p>
    
    <p style="text-align:right;">
        heres some text about the picture under it. 
    </p>
    <p style="text-align:right;">
        <img src="pics/squirrelFight.jpg" style="width:25%; border-radius:10px;">
    </p>
    `;
    
    var ele = document.createElement("div");
    ele.innerHTML = content;
    return ele; 
}