function contact() {

    // ` this is a "back tick". Use it to define multi-line strings in JavaScript.
    var content = ` 
    <p>
        This is a spot to put text content, like your contact info.
        Really it can be anything here, it's just an example of a injected page.
        You can also link emails here, this is mine as an example. 
        <a href=mailto:
        tuj54380@temple.edu?subject="HTML link"> Click here to send me an email</a>
    </p>    
   
    `;
    
    var ele = document.createElement("div");
    ele.innerHTML = content;
    return ele;    
}