function drop (dropHeaderClass,dropContentClass,hideClass, showClass) {
    window.onclick = function (event) {
var clickedEle = event.target; 
                console.log("clickedEle on next line");
                console.log(clickedEle);

                if (clickedEle.classList.contains("dropHeader")) {
                    var nextEle = clickedEle.parentElement.getElementsByClassName("dropContent")[0];
                    console.log("nextEle on next line");
                    console.log(nextEle);
                    if (nextEle.classList.contains("show")) {
                        hide(nextEle);
                    } else {
                        show(nextEle);       
                        hideExcept(nextEle); 
                    }
                } else {
                    
                    hideExcept(null); 
                }
                function hide(ele) {
                    ele.classList.remove("show");
                    ele.classList.add("hide");
                }

                function show(ele) {
                    ele.classList.remove("hide");
                    ele.classList.add("show");
                }
                function hideExcept(ele) {
                    console.log("hiding except ele on next line");
                    console.log(ele);
                    var dropContentList = document.getElementsByClassName("dropContent");
                    for (var i = 0; i < dropContentList.length; i++) {
                        if (dropContentList[i] !== ele) {
                            hide(dropContentList[i]);
                        }
                    }
                } 
} ;
}